/* eslint-disable */
org.test.plugins.dummyplugin/www/dummyplugin.js 
