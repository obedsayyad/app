./org.test.plugins.dummyplugin/src/ios/DummyPluginCommand.m
